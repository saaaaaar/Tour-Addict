<?php  

$host = "localhost"; // Nama hostnya
$username = "root"; // Username
$password = ""; // Password (Isi jika menggunakan password)
$database = "tour-addict"; // Nama databasenya
$koneksi = mysqli_connect($host, $username, $password, $database); // Koneksi ke MySQL
?>