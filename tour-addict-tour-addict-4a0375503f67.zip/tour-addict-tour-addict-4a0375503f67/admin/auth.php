<?php
  include '../conf/koneksi.php';

  if(isset($_POST['submit'])){
      $username = $_POST['username'];
      $password = $_POST['password'];

      $query = "SELECT * FROM `user` WHERE username='$username' and password='$password' and role=1";
      $result = mysqli_query($koneksi,$query) or die(mysql_error());
      $data = mysqli_fetch_assoc($result);
      if(isset($data['id'])){
        session_start();
        $_SESSION['username'] = $username;
        $_SESSION['id'] = $hasil['nik'];
        header('Location: tabel.php'); 
      }else{
        echo"<script>alert('Username atau Password anda salah!');</script>";
      }
  }

?>